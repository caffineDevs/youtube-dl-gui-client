import SearchBox from "./SearchBox/SearchBox";
import "./App.css";


function App() {
  return (
    <div className="App bg-primaryBlack">
      <SearchBox />
    </div>
  );
}

export default App;
